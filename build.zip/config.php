<?php

return [
    'cloudflare' => [
        'email' => '',
        'key'   => '',
    ],
    'wildcard'  => true,
    'server_ip' => '',
];