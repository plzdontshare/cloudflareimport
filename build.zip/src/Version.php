<?php

namespace PlzDontShare\CloudFlareImport;

class Version
{
    const VERSION = "2.0.1";
    const USER_AGENT = "CloudFlareImport";
}