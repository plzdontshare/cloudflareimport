<?php

namespace PlzDontShare\CloudFlareImport;

class Version
{
    const VERSION = "2.0.3";
    const USER_AGENT = "CloudFlareImport";
}