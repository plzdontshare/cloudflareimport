<?php

namespace PlzDontShare\CloudFlareImport;

class APIResponseCodes
{
    const DOMAIN_ALREADY_EXISTS = 1061;
    const MAXIMUM_PURGED_FILES_LIMIT_EXCEEDED = 1094;
    const RECORD_ALREADY_EXISTS = 81057;
}