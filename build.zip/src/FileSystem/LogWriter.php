<?php

namespace PlzDontShare\CloudFlareImport\FileSystem;

class LogWriter
{
    
}