<?php

define('ROOT_PATH', realpath(dirname(__FILE__)));
define('SRC_PATH', ROOT_PATH . '/src');

ini_set('display_errors', true);
ini_set('max_execution_time', 0);
set_time_limit(0);
error_reporting(E_ALL);